﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using DALComponent;
using NoahWebLib.NoahWebFunction;
using NoahWebLib.NoahWebDataAccess;
using NoahWebLib.Security;
using NoahWebLib.NoahWebUI;

//namespace Noah_Web
//{
public partial class APPaymentReqDtlReport : System.Web.UI.Page
{
    #region dont change/modify Default
    nwAction nwAction = new nwAction();
    nwConfiguration nwConfig = new nwConfiguration();
    nwEntry based = new nwEntry();
    private string Connection = "";

    public void gatewayInitialize()
    {
        based.SecurityAccess.Add = true;
        based.SecurityAccess.Access = true;
        based.SecurityAccess.Add = true;
        based.SecurityAccess.Delete = true;
        based.SecurityAccess.Edit = true;
        based.SecurityAccess.Import = true;
        based.SecurityAccess.Print = true;
        based.SecurityAccess.Export = true;
        based.SecurityAccess.Process = true;
        based.SecurityAccess.Save = true;
        based.SecurityAccess.RecUser = "JNS";
        based.SecurityAccess.Company = "FORECASTING AND PLANNING TECHNOLOGIES, INC.";
        based.SecurityAccess.ConnectionString = "";
        try
        {
            based.SecurityAccess.ConnectionString = ConfigurationSettings.AppSettings["NoahWebConnectARK"].ToString();
        }
        catch { }
        try
        {
            this.Connection = ConfigurationSettings.AppSettings["NoahWebConnect"].ToString();
        }
        catch { }

        based.Title = "Promptus 8";
    }
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        gatewayInitialize();
        string strUser = "";
        try
        {
            strUser = Request.QueryString["nwu"].ToString();
            string str = strUser;
            nwConfig.user(ref str);

            based.SecurityAccess.RecUser = str;
        }
        catch { }

        MenuItemAccessibility mia = new MenuItemAccessibility();
        nwAction.js.ADD("try{" + mia.GetMenuItemAccess(Page, "APPaymentReqDtlReport") + "}catch(err){alert(err);}");
        Response.Write("<div id=\"noahwebInitialLoading\">Loading...</div>");        

        nwAction.nwToolBox.bindingNavigatorSaveItem.Visible =
        nwAction.nwToolBox.bindingNavigatorPrintItem.Visible =
        nwAction.nwToolBox.bindingNavigatorInquireItem.Visible =
        nwAction.nwToolBox.bindingNavigatorImportItem.Visible =
        nwAction.nwToolBox.bindingNavigatorPrintItem.Visible =
        nwAction.nwToolBox.bindingNavigatorDeleteItem.Visible =
        nwAction.nwToolBox.bindingNavigatorExportItem.Enable =
        nwAction.nwToolBox.bindingNavigator.Visible =

        nwAction.nwToolBox.bindingNavigatorProcessItem.Visible = false;


        Label lblnwgen = new Label();
        lblnwgen.Text = nwAction.js.makeJSPostScript(nwAction.execute());
        this.Controls.Add(lblnwgen);
    }

    public void btnSubmit_ServerClick(object sender, EventArgs e)
    {
        APPaymentReqDtlReportDAL dal = new APPaymentReqDtlReportDAL(this.Connection, based.SecurityAccess.ConnectionString, "");
        string subPath = dal.GetUploadPath();
        string FilePath = subPath.Replace(HttpContext.Current.Server.MapPath("~/"), "~/").Replace(@"\", "/");

        bool exists = System.IO.Directory.Exists(FilePath);

        if (!exists)
            System.IO.Directory.CreateDirectory(FilePath);


        string FileName = "Collection_Efficiency_per_Business_Unit.csv";
        string filePath = string.Format(@"{0}\{1}", FilePath, FileName);
        HttpResponse response = System.Web.HttpContext.Current.Response;
        response.ClearContent();
        response.Clear();
        response.ContentType = "text/plain";
        response.AddHeader("Content-Disposition", "attachment; filename=" + FileName + ";");
        response.TransmitFile(filePath);


        response.Flush();
        response.End();


    }
}
//}
