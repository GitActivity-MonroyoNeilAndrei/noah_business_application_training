﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using NoahWebLib;
using NoahWebLib.NoahWebFunction;
using NoahWebLib.NoahWebDataAccess;
using NoahWebLib.Security;
using NoahWebLib.NoahWebUI;

using System.Globalization;

using DALComponent;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace Noah_Web.forms_BusinessLayer
{
    public class APPaymentReqDtlReportBL : nwAction
    {
        static int SPR_STARTINDEX = 0,
                  SPR_PAYMENTREQUESTNO = ++SPR_STARTINDEX,
                  SPR_APVNO = ++SPR_STARTINDEX,
                  SPR_POSTINGDATE = ++SPR_STARTINDEX,
                  SPR_REFERENCENO = ++SPR_STARTINDEX,
                  SPR_REFERENCEDATE = ++SPR_STARTINDEX,
                  SPR_DRCOCNO = ++SPR_STARTINDEX,
                  SPR_DRCOCDATE = ++SPR_STARTINDEX,
                  SPR_PAYEECODE = ++SPR_STARTINDEX,
                  SPR_PAYEENAME = ++SPR_STARTINDEX,
                  SPR_CURRENCY = ++SPR_STARTINDEX,
                  SPR_PRFREMARKS = ++SPR_STARTINDEX,
                  SPR_APVPARTICULARS = ++SPR_STARTINDEX,
                  SPR_ITEMGROUPTYPECODE = ++SPR_STARTINDEX,
                  SPR_ITEMGROUPTYPEDESC = ++SPR_STARTINDEX,
                  SPR_ITEMCODE = ++SPR_STARTINDEX,
                  SPR_ITEMDESC = ++SPR_STARTINDEX,
                  SPR_UOM = ++SPR_STARTINDEX,
                  SPR_QTY = ++SPR_STARTINDEX,
                  SPR_UNITCOSTVATIN = ++SPR_STARTINDEX,
                  SPR_UNITCOSTVATEX = ++SPR_STARTINDEX,
                  SPR_OCYAMOUNTVATIN = ++SPR_STARTINDEX,
                  SPR_OCYAMOUNTVATEX = ++SPR_STARTINDEX,
                  SPR_VAT = ++SPR_STARTINDEX,
                  SPR_EWT = ++SPR_STARTINDEX,
                  SPR_TOTALAMOUNT = ++SPR_STARTINDEX,
                  SPR_TAXDESCVAT = ++SPR_STARTINDEX,
                  SPR_TAXDESCEWT = ++SPR_STARTINDEX,
                  SPR_ACCOUNTDESCRIPTION = ++SPR_STARTINDEX,
                  SPR_SEG1 = ++SPR_STARTINDEX,
                  SPR_SEG2 = ++SPR_STARTINDEX,
                  SPR_SEG3 = ++SPR_STARTINDEX,
                  SPR_SEG4 = ++SPR_STARTINDEX,
                  SPR_SEG5 = ++SPR_STARTINDEX,
                  SPR_SEG6 = ++SPR_STARTINDEX,
                  SPR_OTHERREFERENCENO = ++SPR_STARTINDEX,
                  SPR_OTHERREFERENCEDATE = ++SPR_STARTINDEX,
                  SPR_REMARKSPERLINEITEM = ++SPR_STARTINDEX,
                  SPR_CONSUMPTION = ++SPR_STARTINDEX;

        const int SPR_EndOfHdrRow = 7;

        #region Variables needed
        string _strFinal = ""; // container of string result
        string _strmet = "";
        string _strParameter = "";
        string _strValue = "";
        string _strtool_Met = "";
        string _strtool_Poz = "";
        string _strtemp1 = "";
        string _strtemp2 = "";
        string _strtemp3 = "";
        string _strtemp4 = "";
        string _strtemp5 = "";
        string UserDefinedConnectionString = "";
        bool isNewRow;
        string ToolboxOrderData = ""; // toolbox Orderby

        DataTable emptyDT;

        public string Result = "";
        nwEntry based = new nwEntry();
        #endregion

        #region Standard Functionality
        WebApplib WebApp = new WebApplib();
        Promptlib custom_Prompt = new Promptlib();
        nwObject nwObject = new nwObject();
        DataAccess nwDataAccess = new DataAccess();
        JSFunction custom_js = new JSFunction();
        nwAction nwAction = new nwAction();
        nwSFObjects SFObjects = new nwSFObjects();
        #endregion

        public void main(ref string strFinal, string strmet,
           string strParameter, string strValue, string strtool_Met,
           string strtool_Poz, string strtemp1, string strtemp2,
           string strtemp3, string strtemp4, string strtemp5, ref nwEntry baseds, string UserDefinedConnection)
        {

            _strmet = strmet;
            _strParameter = strParameter;
            _strValue = strValue;
            _strtool_Met = strtool_Met;
            _strtool_Poz = strtool_Poz;
            _strtemp1 = strtemp1;
            _strtemp2 = strtemp2;
            _strtemp3 = strtemp3;
            _strtemp4 = strtemp4;
            _strtemp5 = strtemp5;
            based = baseds;
            this.UserDefinedConnectionString = UserDefinedConnection;
            //Addchars();
            dal = new APPaymentReqDtlReportDAL(this.UserDefinedConnectionString, based.SecurityAccess.ConnectionString, "");
            if (_strmet == "get_Initialize") strFinal = get_Initialize();
            else if (_strmet == "func_Toolbox") strFinal = func_Toolbox(strtool_Met, strtool_Poz, strParameter, strValue);
            else if (_strmet == "get_LookUp") strFinal = get_LookUp(strtool_Met, strtool_Poz, strParameter, strValue);            
            else if (_strmet == "getToolBoxData") strFinal = getToolBoxData(strtemp1, strtemp2, strParameter, strValue);
            else if (_strmet == "get_Method") strFinal = get_Method(strtemp1, strtemp2, strParameter, strValue);
            else if (_strmet == "act_Method") strFinal = act_Method(strtool_Met, strParameter, strValue);
            else strFinal = js.makeJSPostScript("alert('error:" + strmet + " not excute');");

            Result = strFinal;
        }

        public string strConn = "";
        string RecordOperationResult = String.Empty;
        APPaymentReqDtlReportDAL dal;
        int xtotalrecords = 0;
        Dictionary<string, string> xdic_chars = new Dictionary<string, string>();


        public APPaymentReqDtlReportBL()
        {
            //dal = new DataAccessLayer(this.UserDefinedConnectionString,""); 
        }

        #region Dont Change

        public string func_Toolbox(string strMethod, string poz, string strParameter, string strValue)
        {

            try
            {
                WebApp = new WebApplib(strParameter, strValue);
                int pozt = -1;
                try { pozt = Convert.ToInt32(poz); }
                catch { }
                try
                {

                    isNewRow = WebApp.nwobjectBool("isNewRow");
                }
                catch { }
                string strF = "";
                #region do not change (calling RecordOperation)
                switch (strMethod)
                {
                    case "0":
                        RecordOperation(eRecordOperation.AddNew, pozt);
                        break;
                    case "1":
                        RecordOperation(eRecordOperation.Save, pozt);
                        if (String.IsNullOrEmpty(RecordOperationResult) == true) strF = "isNewRow=false;" + strF;
                        break;
                    case "2":
                        RecordOperation(eRecordOperation.Delete, pozt);
                        break;
                    case "3":
                        RecordOperation(eRecordOperation.Refresh, pozt);
                        break;
                    case "4":
                        RecordOperation(eRecordOperation.Inquire, pozt);
                        break;
                    case "5":
                        RecordOperation(eRecordOperation.Process, pozt);
                        break;
                    case "6":
                        RecordOperation(eRecordOperation.Import, pozt);
                        break;
                    case "7":
                        RecordOperation(eRecordOperation.Export, pozt);
                        break;
                    case "8":
                        RecordOperation(eRecordOperation.Print, pozt);
                        break;
                    case "9":
                        RecordOperation(eRecordOperation.Closing, pozt);
                        break;
                    case "10":
                        RecordOperation(eRecordOperation.Search, pozt);
                        break;
                }
                #endregion
                //strF += ";" + Prompt.Excute();
                strF += execute();
                return js.makeJSPostScript(strF);

            }
            catch (Exception err)
            {
                return err.ToString();
            }
        }
        public string get_LookUp(string strSearch, string poz, string strParameter, string strValue)
        {
            string strFinal = "";
            WebApp = new WebApplib(strParameter, strValue);
            strFinal += get_Method(strSearch, poz, strParameter, strValue);
            if (strFinal.Trim() == "") strFinal = "<tr><td>Error Occur.<td></tr>";
            strFinal = js.makeHTML("#menuCreatorContainer .tablecontainter", strFinal);
            strFinal = js.makeJSPostScript(strFinal);
            return strFinal;
        }      
        #endregion

        public string get_Method(string strMethod, string strSearchVal, string strParameter, string strValue)
        {
            WebApp = new WebApplib(strParameter, strValue);
            DataTable dtLookupConfig = WebApp.get_LookupConfig();
            nwObject.LookupConfig(dtLookupConfig);

            string strFinal = "";
            string strSQL = "";
            string mouseDownFunc = "";
            string mouseOverFunc = "";
            string strName = "";
            strConn = this.UserDefinedConnectionString;

            DateTime dateFilterFrom = Parser.ParseDateTime(WebApp.nwobjectDate("dateFilterFrom"), Parser.DateTimeType.Min);
            DateTime dateFilterTo = Parser.ParseDateTime(WebApp.nwobjectDate("dateFilterTo"), Parser.DateTimeType.Min);

            //string sortType = Parser.ParseString(WebApp.nwobjectText("SortType"));

            int rbPCCA = WebApp.nwobjectBool("rbPCCA") ? 1 : 0;
            string Location = WebApp.nwobjectText("Location");
            string Payee = WebApp.nwobjectText("Payee");
            string PaymentRequestNo = WebApp.nwobjectText("PaymentRequestNo");
            string APVNo = WebApp.nwobjectText("APVNo");
            string ReferenceNo = WebApp.nwobjectText("ReferenceNo");

            switch (strMethod)
            {
                case "gettoolboxInquire":
                    strSQL = dal.INQUIREQUERY(based.SecurityAccess.RecUser);
                    strMethod = strMethod.Substring(3);
                    strFinal = nwObject.make_TableLookup(strMethod, strSQL, strConn, emptyDT, mouseDownFunc, mouseOverFunc);
                    break;

                case "getLocation":
                    strSQL = dal.getAddToList(2, rbPCCA, dateFilterFrom.ToString("MM/dd/yyyy"), dateFilterTo.ToString("MM/dd/yyyy"), Location, Payee, PaymentRequestNo, APVNo, ReferenceNo, based.SecurityAccess.RecUser);
                    strMethod = strMethod.Substring(3);
                    strFinal = nwObject.make_TableLookupList(strMethod, strSQL, strConn, emptyDT, mouseDownFunc, mouseOverFunc);
                    break;

                case "getPayee":
                    strSQL = dal.getAddToList(3, rbPCCA, dateFilterFrom.ToString("MM/dd/yyyy"), dateFilterTo.ToString("MM/dd/yyyy"), Location, Payee, PaymentRequestNo, APVNo, ReferenceNo, based.SecurityAccess.RecUser);
                    strMethod = strMethod.Substring(3);
                    strFinal = nwObject.make_TableLookupList(strMethod, strSQL, strConn, emptyDT, mouseDownFunc, mouseOverFunc);
                    break;

                case "getPaymentRequestNo":
                    strSQL = dal.getAddToList(4, rbPCCA, dateFilterFrom.ToString("MM/dd/yyyy"), dateFilterTo.ToString("MM/dd/yyyy"), Location, Payee, PaymentRequestNo, APVNo, ReferenceNo, based.SecurityAccess.RecUser);
                    strMethod = strMethod.Substring(3);
                    strFinal = nwObject.make_TableLookupList(strMethod, strSQL, strConn, emptyDT, mouseDownFunc, mouseOverFunc);
                    break;

                case "getAPVNo":
                    strSQL = dal.getAddToList(5, rbPCCA, dateFilterFrom.ToString("MM/dd/yyyy"), dateFilterTo.ToString("MM/dd/yyyy"), Location, Payee, PaymentRequestNo, APVNo, ReferenceNo, based.SecurityAccess.RecUser);
                    strMethod = strMethod.Substring(3);
                    strFinal = nwObject.make_TableLookupList(strMethod, strSQL, strConn, emptyDT, mouseDownFunc, mouseOverFunc);
                    break;
            }

            return strFinal;
        }

        ///// Standard RecordOperation 

        public void RecordOperation(eRecordOperation i, int Position)
        {
            string result = "", tempstr = "";
            DataTable dt = new DataTable();

            switch (i)
            {
                case eRecordOperation.AddNew:
                    nwToolBox.bindingNavigatorSaveItem.Enable = true;
                    nwToolBox.bindingNavigatorAddNewItem.Enable =
                    nwToolBox.bindingNavigatorPrintItem.Enable =
                    nwToolBox.bindingNavigatorInquireItem.Enable =
                    nwToolBox.bindingNavigatorImportItem.Visible =
                    nwToolBox.bindingNavigatorDeleteItem.Enable =
                    nwToolBox.bindingNavigatorDeleteItem.Visible =
                    nwToolBox.bindingNavigatorExportItem.Enable = false;

                    GenerateGrid(true);
                    DateTime date = DateTime.Now;
                    js.ADD($"$('#txtValueDate').val('{date.ToString("MM/dd/yyyy")}');");
                    LoadComboBox();
                    //js.ADD("$('.spantext').remove()");

                    string date1 = SFObject.GetServerDateTime(UserDefinedConnectionString).ToString("MM/dd/yyyy");
                    string year = Parser.ParseString(SFObject.GetServerDateTime(UserDefinedConnectionString).Year);

                    var now = DateTime.Now;
                    var startOfMonth = new DateTime(now.Year, now.Month, 1);

                    //js.ADD($"$('#cboAnnual').val('{SFObject.GetServerDateTime(UserDefinedConnectionString).Year}');");
                    //js.ADD("$('#cboAnnual').trigger('change');");
                    //js.ADD("ReloadMonth(); ReloadQuarter(); DisableFields(); ClearDateFilter();");
                    //js.ADD("$('#rbMonthly').prop('checked', true);");
                    //js.ADD("$('#cboMonthly').enable(true)");
                    js.ADD($"currentDate='{date1}';");
                    js.ADD($"firstDay='{string.Format("{0:MM/dd/yyyy}", startOfMonth)}';");
                    js.ADD($"currentYear='{year}';");
                    loaddefault();
                    DateTime serverdate = SFObjects.GetServerDateTime(this.UserDefinedConnectionString).Date;
                    js.makeValueText("#dtpFrom", serverdate.ToString("MM/dd/yyyy"));
                    js.makeValueText("#dtpTo", serverdate.ToString("MM/dd/yyyy"));
                    //js.ADD($"$('select#cboMonthly').val('{now.Month}')");

                    DateTime currentDate = SFObject.GetServerDateTime(this.UserDefinedConnectionString);
                    js.makeValueText("#txtAnually", currentDate.ToString("yyyy"));
                    js.ADD("ReloadQuarter(); ReloadMonth(); EnableFields(); ClearFields(); $('#cboMonthly').enable(true); $('#rbMonthly').prop('checked',true);");
                    js.ADD($"$('select#cmbMonth').val({currentDate.Month})");
                    js.ADD("CurrentDate = '" + currentDate.ToString("MM/dd/yyyy") + "'");
                    js.ADD("setToCurrentDate();");
                    break;

                case eRecordOperation.Save:
                    RecordOperationResult = AreValidEntries();

                    if (RecordOperationResult == "")
                    {
                        //DataTable dtHDR = LoadSchema();
                        //RecordOperationResult = dal.SaveData(dtHDR, isNewRow);
                    }
                    break;

                case eRecordOperation.Delete:
                    //RecordOperationResult = dal.DeleteData(WebApp.nwobjectText("txtDocno"), based.SecurityAccess.RecUser);
                    break;

                case eRecordOperation.Process:
                    //GenerateGridProcess(true, "LoadDetails");
                    break;
                case eRecordOperation.Refresh:
                    nwAction.nwToolBox.bindingNavigatorExportItem.Enable = true;
                    RefreshData();
                    js.ADD("nwLoading_End('xRefreshBtn');");
                    break;
                case eRecordOperation.Inquire:
                    tempstr = "inqure";
                    break;
                case eRecordOperation.Import:
                    break;
                case eRecordOperation.Export:

                    DataTable dt1 = new DataTable();

                    ListingAndPrint frmlist = new ListingAndPrint(ListingAndPrint.FormType.NOAH_Standard1, 8, dal.LoadSchema(), "", this.UserDefinedConnectionString, SFObjects.returnText(dal.GETCOMPANY, UserDefinedConnectionString), based.SecurityAccess.RecUserName, "");

                    int rowCnt = 0;
                    int colCnt = SPR_CURRENCY;

                    DateTime dateFilterFrom = Parser.ParseDateTime(WebApp.nwobjectDate("dateFilterFrom"), Parser.DateTimeType.Min);
                    DateTime dateFilterTo = Parser.ParseDateTime(WebApp.nwobjectDate("dateFilterTo"), Parser.DateTimeType.Min);

                    string sortType = Parser.ParseString(WebApp.nwobjectText("SortType"));

                    int rbPCCA = WebApp.nwobjectBool("rbPCCA") ? 1 : 0;
                    string Location = WebApp.nwobjectText("Location");
                    string Payee = WebApp.nwobjectText("Payee");
                    string PaymentRequestNo = WebApp.nwobjectText("PaymentRequestNo");
                    string APVNo = WebApp.nwobjectText("APVNo");
                    string ReferenceNo = WebApp.nwobjectText("ReferenceNo");

                    string recuser = based.SecurityAccess.RecUser;

                    string LISTINGFILENAME = "Daily Collection";
                    if (dal.LISTINGFILENAME + " Listing" == "") LISTINGFILENAME = "Sheet 1";
                    else LISTINGFILENAME = dal.LISTINGFILENAME + " Listing";

                    dt1 = dal.GetReportData(dateFilterFrom.ToString("MM/dd/yyyy"), dateFilterTo.ToString("MM/dd/yyyy"), rbPCCA, false, recuser, Location, Payee, PaymentRequestNo, APVNo, ReferenceNo);

                    frmlist = new ListingAndPrint(ListingAndPrint.FormType.NOAH_Standard1, 11, dt1, "", this.UserDefinedConnectionString, SFObjects.returnText(dal.GETCOMPANY, UserDefinedConnectionString), based.SecurityAccess.RecUserName, "");
                    frmlist.m_Spread.SetText(1, 1, SFObjects.returnText(dal.GETCOMPANY, UserDefinedConnectionString));
                    frmlist.m_Spread.SetText(1, 2, "Location Name: " + WebApp.nwobjectText("LocationFilter"));
                    frmlist.m_Spread.SetText(1, 3, LISTINGFILENAME);
                    frmlist.m_Spread.SetText(1, 4, "System User: " + SFObject.returnText("select [SG].[GetEmpName]('" + based.SecurityAccess.RecUser + "')", this.UserDefinedConnectionString));
                    frmlist.m_Spread.SetText(1, 5, "System Date: " + SFObject.GetServerDateTime(this.UserDefinedConnectionString));

                    //## FOR EXPORTING ###
                    Random rnd = new Random();
                    string SessionID = DateTime.Now.ToString("yyyyddMMhhmmss") + rnd.Next(0, 9999).ToString().PadRight(4, '0');
                    HttpContext.Current.Session["Config_" + SessionID] = frmlist.m_Spread.ExportConfig();
                    HttpContext.Current.Session["Data_" + SessionID] = frmlist.m_Spread.GetDataSource();
                    HttpContext.Current.Session["Filename_" + SessionID] = LISTINGFILENAME;
                    HttpContext.Current.Session["Header_" + SessionID] = "0";
                    js.ADD("ExportSessionID='" + SessionID + "'");

                    //## END ##
                    js.Show("#nwExportContainerMain", 0);
                    js.ADD(frmlist.CreateScript());

                    break;
                case eRecordOperation.Print:
                    break;
                case eRecordOperation.Closing:
                    break;
                case eRecordOperation.Search:
                    break;
            }

            if (RecordOperationResult != String.Empty)
            {
                if (RecordOperationResult.IndexOf("Error") == 0 || RecordOperationResult.Contains("Cannot"))
                {
                    Prompt.Error(RecordOperationResult, based.Title);
                }
                else
                {
                    RefreshData();
                    js.ADD("loc_LookupInquireWithValue('" + dal.docno + "') ");
                    RecordOperationResult = Prompt.PromptToolBoxMessage(RecordOperationResult, i);
                    Prompt.Information(RecordOperationResult, based.Title);

                }
            }


            //return result;
        }

        private void LoadComboBox()
        {
            js.makeComboBox("#cboAnnual", dal.GetYearList());
        }


        private DataTable SetColumnFilter()
        {
            DataTable dtFilter = new DataTable();
            dtFilter.Columns.Add("Code");
            dtFilter.Columns.Add("Description");
            DataRow dr;

            int col = 1;
            foreach (DataColumn dc in dal.getColumnNameFilter().Columns)
            {
                dr = dtFilter.NewRow();

                dr["Code"] = dc.ColumnName.ToString();
                dr["Description"] = dc.ColumnName.ToString();

                dtFilter.Rows.Add(dr);
                dtFilter.AcceptChanges();
                col++;
            }

            return dtFilter;
        }

        private void loaddefault()
        {           
            DataTable dtLoc = dal.getDefloc(based.SecurityAccess.RecUser);
            if (dtLoc.Rows.Count > 0)
                js.makeAppend(".atl_Location .innertext", $"<div class='spantext' nwcode='{dtLoc.Rows[0][0].ToString()}' class='nwCuz024'>{dtLoc.Rows[0][1].ToString()}<span class='classx'>x</span></div>");
        }

        ////////////////////// For Customize 
        public string get_Initialize()
        {
            string strFinal = "";

            SetBindings();
            Main_Load();

            execute(ref strFinal);

            return js.makeJSPostScript(strFinal);
        }
        public string act_Method(string strMethod, string strParameter, string strValue)
        {
            string strFinal = "", strSQL = "";
            WebApp = new WebApplib(strParameter, strValue);
            switch (strMethod)
            {
                case "actBindCollection":
                    BindCollection();
                    break;

                case "actBindCollectionEmpty":
                    js.ADD("nwLoading_End('xSample')");
                    break;

                case "actGenerateText":
                    string message = string.Empty;

                    message = GenerateTextFile();

                    Prompt.Information(message, based.Title);
                    js.ADD("nwLoading_End('xGenerateTxt')");
                    js.ADD("nwLoading_End('xSample')");
                    break;
                default:
                    Prompt.Information("act_Method not found: " + strMethod, "Error");
                    break;
            }
            return js.makeJSPostScript(execute());
        }
        public string getToolBoxData(string tableName, string getMethod, string strParameter, string strValue)
        {
            string strFinal = ""; string sql = "";
            WebApp = new WebApplib(strParameter, strValue);
            switch (getMethod)
            {
                case "toolbox":
                    nwStandardBL standardBL = new nwStandardBL(WebApp);
                    standardBL.PrimaryKey = "Docno";
                    strFinal = standardBL.LoadToolBoxData("#noah-webui-Toolbox-BindingNavigator", dal.GetData(based.SecurityAccess.RecUser), this.UserDefinedConnectionString);
                    break;
            }

            return strFinal;
        }

        //////////////////////// Common
        private void SetBindings()
        {
            //FOOTER
            SFObject.SetControlBinding("#nwtxt_RecUser", "text", "", "#noah-webui-Toolbox-BindingNavigator", "RECUSER");
            SFObject.SetControlBinding("#nwtxt_RecDate", "text", "", "#noah-webui-Toolbox-BindingNavigator", "RECDATE");
            SFObject.SetControlBinding("#nwtxt_ModUser", "text", "", "#noah-webui-Toolbox-BindingNavigator", "MODUSER");
            SFObject.SetControlBinding("#nwtxt_ModDate", "text", "", "#noah-webui-Toolbox-BindingNavigator", "MODDATE");
        }

        //////////////// end of standard / standard custumize

        private void BindCollection()
        {
            js.ADD("nwLoading_End('xSample');");
        }

        private string AreValidEntries()
        {
            string errorResult = String.Empty;

            return errorResult;
        }

        private bool ValidateDate(string bGetDate)
        {
            try
            {
                Convert.ToDateTime(bGetDate);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Data_Enable()
        {
            nwToolBox.bindingNavigatorAddNewItem.Enable =
            nwToolBox.bindingNavigatorSaveItem.Enable =
            nwToolBox.bindingNavigatorPrintItem.Enable =
            nwToolBox.bindingNavigatorInquireItem.Enable =
            nwToolBox.bindingNavigatorDeleteItem.Enable =
            nwToolBox.bindingNavigatorExportItem.Enable = true;

            nwToolBox.bindingNavigatorExportItem.Visible = true;

            nwToolBox.bindingNavigatorImportItem.Visible =
            nwToolBox.bindingNavigatorProcessItem.Visible = false;
        }


        private void Main_Load()
        {
            if (based.isInterface == true) dal.UpdateVersion();
            LoadComboBox();

            string date = dal.getServerDate();
            string year = Parser.ParseString(Parser.ParseDateTime(dal.getServerDate(), Parser.DateTimeType.Min).Year);
            string month = Parser.ParseString(Parser.ParseDateTime(dal.getServerDate(), Parser.DateTimeType.Min).Month);
            //js.ADD($"$('#cboAnnual').val('{year}');");
            //js.ADD("$('#cboAnnual').trigger('change');");
            //js.ADD("ReloadMonth(); ReloadQuarter(); DisableFields(); ClearDateFilter();");
            //js.ADD("$('#rbMonthly').prop('checked', true);");
            //js.ADD("$('#cboMonthly').enable(true)");
            js.ADD($"currentDate='{date}';");
            js.ADD($"currentYear='{year}';");
            //js.ADD($"$('select#cboMonthly').val('{month}')");
            js.ADD($"menuTitle = '{based.Title}'");

            if (dal.chkRptAccAssgn(based.SecurityAccess.RecUser) != "1")
                js.makeProp("#rbACCA", "disabled", "true");

            string lblcc = dal.chkLabelCC();
            if (lblcc != "")
            {
                js.ADD($"lblCC = '{lblcc}'");
                js.makeHTML("#lblCC", "Per " + lblcc + " Access");
            }

            GenerateGrid(true);
            loaddefault();
            DateTime currentDate = SFObject.GetServerDateTime(this.UserDefinedConnectionString);
            js.makeValueText("#txtAnually", currentDate.ToString("yyyy"));
            js.ADD("ReloadQuarter(); ReloadMonth(); EnableFields(); ClearFields(); $('#cboMonthly').enable(true); $('#rbMonthly').prop('checked',true);");
            js.ADD($"$('select#cmbMonth').val({currentDate.Month})");
            js.ADD("CurrentDate = '" + currentDate.ToString("MM/dd/yyyy") + "'");
            js.ADD("setToCurrentDate();");
        }

        private void RefreshData()
        {
            string errorResult = string.Empty;

            GenerateGrid(false);
            js.ADD("getloadfilter();");
            nwAction.nwToolBox.bindingNavigatorExportItem.Enable = true;


            //js.ADD("ClearFields();");
            //js.ADD("func_Toolbox_Clear();");
            //js.ADD("func_ToolboxData(\"#noah-webui-Toolbox-Grid\", \"toolbox\");"); // goto: getToolBoxData
            //js.ADD("RefreshData();");
        }

        public void GenerateGrid(bool load)
        {
            string gridID = "nwGridCon";
            nwGrid nwGridCon = new nwGrid(gridID);
            DataTable dt = new DataTable();

            DateTime dateFilterFrom = Parser.ParseDateTime(WebApp.nwobjectDate("dateFilterFrom"), Parser.DateTimeType.Min);
            DateTime dateFilterTo = Parser.ParseDateTime(WebApp.nwobjectDate("dateFilterTo"), Parser.DateTimeType.Min);

            //string sortType = Parser.ParseString(WebApp.nwobjectText("SortType"));

            int rbPCCA = WebApp.nwobjectBool("rbPCCA") ? 1 : 0;
            string Location = WebApp.nwobjectText("Location");
            string Payee = WebApp.nwobjectText("Payee");
            string PaymentRequestNo = WebApp.nwobjectText("PaymentRequestNo");
            string APVNo = WebApp.nwobjectText("APVNo");
            string ReferenceNo = WebApp.nwobjectText("ReferenceNo");

            dt = dal.GetReportData(dateFilterFrom.ToString("MM/dd/yyyy"), dateFilterTo.ToString("MM/dd/yyyy"), rbPCCA, load, based.SecurityAccess.RecUser, Location, Payee, PaymentRequestNo, APVNo, ReferenceNo);

            ListingAndPrint frmlist = new ListingAndPrint(ListingAndPrint.FormType.NOAH_Standard1, 10, dt, "", UserDefinedConnectionString, SFObjects.returnText(dal.GETCOMPANY, UserDefinedConnectionString), based.SecurityAccess.RecUserName, "");

            frmlist.SetSpreadType(nwGridType.SpreadCanvas);

            frmlist.MenuItemName = based.Title;            
            frmlist.m_Spread.SetText(1, 5, "LOCATION NAME: ");

            if (load)
            {
                frmlist.LOCATION_NAME = "All Locations";
            }
            else
            {
                frmlist.LOCATION_NAME = WebApp.nwobjectText("LocationFilter");
            }
            
            string DateGridHeader = dateFilterFrom.ToShortDateString();
            if (DateGridHeader == "1/1/1900")
            {
                DateGridHeader = dal.getServerDate();
            }
            else
            {
                DateGridHeader = dal.getServerDate();
            }


            //DateGridHeader = "As of Date: " + DateGridHeader;
            frmlist.DATE_PARAMETER = WebApp.nwobjectText("DateGridHeader");


            if (dt.Rows.Count <= 0)
            {
                int i = dt.Columns.Count;
                for (int d = 0; d < i; d++)
                {
                    for (int a = 13; a <= dt.Rows.Count; a++)
                    {
                        frmlist.m_Spread.SetText(d, a, "");
                    }
                }
            }

            frmlist.m_Spread.minRow(0);
            frmlist.m_Spread.TableHeight(400);
            frmlist.m_Spread.RowHeight(10);

            frmlist.m_Spread.Rows(0).FontWeight("Bold");
            frmlist.m_Spread.Rows(1).FontWeight("Bold");
            frmlist.m_Spread.Rows(2).FontWeight("Bold");
            frmlist.m_Spread.Rows(3).FontWeight("Bold");
            frmlist.m_Spread.Rows(4).FontWeight("Bold");
            frmlist.m_Spread.Rows(5).FontWeight("Bold");
            frmlist.m_Spread.Rows(6).FontWeight("Bold");
            frmlist.m_Spread.Rows(7).FontWeight("Bold");
            frmlist.m_Spread.Rows(8).FontWeight("Bold");

            frmlist.m_Spread.nwobject(SPR_QTY - 1).TextAlign("right");
            frmlist.m_Spread.nwobject(SPR_UNITCOSTVATIN - 1).TextAlign("right");
            frmlist.m_Spread.nwobject(SPR_UNITCOSTVATEX - 1).TextAlign("right");
            frmlist.m_Spread.nwobject(SPR_OCYAMOUNTVATIN - 1).TextAlign("right");
            frmlist.m_Spread.nwobject(SPR_OCYAMOUNTVATEX - 1).TextAlign("right");

            frmlist.m_Spread.PagerPerPage(100);
            frmlist.m_Spread.ExportFileName = based.Title;

            frmlist.m_Spread.buttonSearchFind = true;
            frmlist.m_Spread.GetSaveWith(this.UserDefinedConnectionString, dal.MenuItemCode + "-1", based.SecurityAccess.RecUser);
            frmlist.m_Spread.buttonResetColumn = true;
            frmlist.m_Spread.buttonSaveColumn = true;

            //NEWCODE
            frmlist.m_Spread.buttonExport = true;
            frmlist.m_Spread.buttonExportHide = true;
            frmlist.m_Spread.GetSaveSort(this.UserDefinedConnectionString, dal.MenuItemCode /*+"#reporcode#" */ + "-1", based.SecurityAccess.RecUser); // this line will be default and suggested line code if there are many grid in one menu item  change -1 to -2 and so on...
            frmlist.m_Spread.buttonSortColumn = true;  // show Sort Menu

            //## THEME FORMAT
            frmlist.m_Spread.HeaderBorderColor("#DEDEDE");
            frmlist.m_Spread.rowBackground("#FFFFFF", "#FFFFFF");
            frmlist.m_Spread.TableBorderColor("#BBB");
            frmlist.m_Spread.BodyBorderColor("#BBB");
            frmlist.m_Spread.HeaderBackgroundGradientColor("#FEFEFE", "#DEDEDE");
            frmlist.m_Spread.HeaderTextColor("#131313");
            frmlist.m_Spread.HoverColor("#DEDEDE", "inherit");
            frmlist.m_Spread.SelectedRowHover("#DEDEDE");
            frmlist.m_Spread.SelectedRowHoverColor("inherit");

            //frmlist._MakeFreeze = true;
            //frmlist.FreezeColumn = 5;
            // js.makeHTML("#nwGridMainCon", frmlist.m_Spread.createTable());

            // Added for new Spread
            frmlist.varSpreadBook = "nwGridMainCon_Book";
            frmlist.varSpreadSheet = "nwGridMainCon_Sheet";

            // Updated for new Spread
            js.ADD(frmlist.CreateScript("nwGridMainCon", "nwGridMainCon"));

            //js.ADD(frmlist.CreateScript("nwGridCon", "nwGridView"));
            //js.ADD("nwGrid_TableFreeze(\"" + gridID + "\",0,5)");
            js.makeCSS("#nwGridCon", "border", "1px solid #BBB1B1");
        }


        private void SetSpreadText(ref ListingAndPrint frmlist, int col, int row, string colType, object objValue)
        {
            switch (colType)
            {
                case "System.String":
                    frmlist.m_Spread.SetText(col, row, objValue.ToString());
                    frmlist.m_Spread.Rows(row - 1, col - 1).TextAlign("LEFT");
                    break;

                case "System.Int32":
                    frmlist.m_Spread.SetFloat(col, row, objValue.ToString());
                    frmlist.m_Spread.Rows(row - 1, col - 1).TextAlign("CENTER");
                    break;

                case "System.Decimal":
                    frmlist.m_Spread.SetFloat(col, row, Parser.ParseDecimal(objValue).ToString("#,##0.00"));
                    frmlist.m_Spread.Rows(row - 1, col - 1).TextAlign("RIGHT");
                    break;

                default:
                    frmlist.m_Spread.SetText(col, row, objValue.ToString());
                    frmlist.m_Spread.Rows(row - 1, col - 1).TextAlign("LEFT");
                    break;
            }
        }

        private string GenerateTextFile()
        {
            string message = string.Empty;

            try
            {
                string subPath = dal.GetUploadPath();
                string FilePath = subPath.Replace(HttpContext.Current.Server.MapPath("~/"), "~/").Replace(@"\", "/");
                bool exists = System.IO.Directory.Exists(FilePath);

                if (!exists)
                    System.IO.Directory.CreateDirectory(FilePath);

                String FileName = "Client_Data_Information_Report.csv";
                DataTable dtLin = new DataTable();
                dtLin = WebApp.nwGridData(WebApp.nwobjectText("nwGridCon"));
                //dtLin.Columns.Remove("Column0");
                //string filePath = string.Format(@"{0}\{1}", dal.GetUploadPath(), FileName);
                string filePath = string.Format(@"{0}\{1}", FilePath, FileName);
                string errorMsg = Write(dtLin, filePath, SPR_EndOfHdrRow);

                if (errorMsg.Length > 0)
                {
                    message = errorMsg;
                }
                else
                {
                    js.ADD("serverClick();");
                    message = String.Format(@"File [{0}] created successfully.", FileName);

                }

                //CreateGrid();
            }
            catch (Exception ex)
            {
                message = ex.ToString();
            }

            return message;
        }

        private string Write(DataTable dt, string outputFilePath, int EndOfHdrRow)
        {
            string msg = string.Empty;

            if (dt.Rows.Count > 0)
            {
                int CurrRowIndex = 1;
                using (var sw = new StreamWriter(outputFilePath, false))
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            if (i >= 1)
                                if (CurrRowIndex > EndOfHdrRow)
                                    sw.Write(",");

                            if (!row.IsNull(i))
                            {

                                if ((row[i].ToString().Contains(",") || (row[i].ToString().Contains("\""))))
                                    sw.Write('"' + row[i].ToString().Trim().Replace("\"", "\"\"") + '"' + "");
                                else
                                    sw.Write(row[i].ToString().Trim() + "");
                            }
                        }
                        CurrRowIndex++;
                        sw.WriteLine();
                    }

                    sw.Flush();
                    sw.Close();
                }
            }
            else
                msg = "No records to be generated.";


            return msg;
        }



    }
}