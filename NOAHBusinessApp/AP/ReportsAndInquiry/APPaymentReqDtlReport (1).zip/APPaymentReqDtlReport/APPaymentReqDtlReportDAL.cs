﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using NoahWebLib;
using NoahWebLib.NoahWebFunction;

namespace DALComponent
{
    public class APPaymentReqDtlReportDAL : NoahWebLib.DatabaseHandler
    {
        public string docno = string.Empty;
        private SqlTransaction sqlTrn;
        private SqlConnection sqlConn = new SqlConnection();
        private string storedProcedure = "[AP].[nsp_PaymentReqDtlReport]";

        nwSFObjects SFObjects = new nwSFObjects();
        #region STANDARD

        public string MenuItemCode = "APPaymentReqDtlReport"; // This is default parameter  for version
        public string MenuItemVersion = "9.0.0.0"; // This is default parameter for version
        public string UpdateVersion(string _MenuItemCode, string _MenuItemVersion)
        {
            if (_MenuItemCode.Trim() != "") MenuItemCode = _MenuItemCode;
            if (_MenuItemVersion.Trim() != "") MenuItemVersion = _MenuItemVersion;
            return UpdateVersion();
        }
        public string UpdateVersion()
        {
            #region donot delete Version Updating
            string StrMessage = SFObjects.returnText(
                string.Format(@"
                              declare @MenuCode as nvarchar(max);
                              declare @Version as nvarchar(max);

                              set @MenuCode= '{0}';
                              set @Version = '{1}';

                              Update [FPTI_NW].[noahweb_menuItems_Info]
                              set version=@Version
                              where [Code]=@MenuCode;
                                ", MenuItemCode, MenuItemVersion)
                , _ConnectionString2);
            return StrMessage;
            #endregion
        }

        #endregion
        private string _ConnectionString;
        private string _ConnectionString2;
        public readonly string errorString = "Error",                                     //--do not change this line
                                primaryKey = "Docno";                                     //--column for searching

        private string focusRecordPK = "";
        //#FOR EXPORT
        public string LISTINGFILENAME = "Receiving Report Listing",
                      GETCOMPANY = "select CompanyName from SG.BIRCASConfig";
        public int LISTINGSTARTROW = 5;
        //# END


        public string CurrentSelectedItem;                                                 //-- selected item in binding navigator
        public APPaymentReqDtlReportDAL(string ConnectionString, string ConnectionString2, string selectedItem)
        {
            _ConnectionString = ConnectionString;
            _ConnectionString2 = ConnectionString2;
            this.CurrentSelectedItem = selectedItem;
        }

        public DataTable GetReportData(string dateFrom, string dateTo, int rbPCCA, bool load, string recuser, string Location, string Payee, string PaymentRequestNo, string APVNo, string ReferenceNo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            cmd.CommandText = storedProcedure;
            cmd.Parameters.AddWithValue("@isPerCostCenter", rbPCCA);
            cmd.Parameters.AddWithValue("@dateFrom", dateFrom);
            cmd.Parameters.AddWithValue("@dateTo", dateTo);
            cmd.Parameters.AddWithValue("@locformList", Location);
            cmd.Parameters.AddWithValue("@vendorList", Payee);
            cmd.Parameters.AddWithValue("@prfnoList", PaymentRequestNo);
            cmd.Parameters.AddWithValue("@apvnoList", APVNo);
            cmd.Parameters.AddWithValue("@refnoList", ReferenceNo);
            cmd.Parameters.AddWithValue("@Recuser", recuser);

            if (load)
                cmd.Parameters.AddWithValue("@QueryType", 1);
            else
                cmd.Parameters.AddWithValue("@QueryType", 0);

            return base.ExecGetData(cmd, _ConnectionString);
        }

        public DataTable GetYearList()
        {
            return SFObjects.LoadDataTable($"EXEC {storedProcedure} @QueryType = 7", _ConnectionString);
        }

        public DataTable getDefloc(string user)
        {
            return SFObjects.LoadDataTable($"EXEC {storedProcedure} @Recuser = '{user}', @QueryType = 8", _ConnectionString);
        }

        public string GetData(string recuser)
        {
            string a = string.Format($"EXEC [RE].[nsp_TRANSFERACTIVITY] @Recuser = '{recuser}', @QueryType = 0");
            focusRecordPK = string.Empty;
            a = a.Replace(Environment.NewLine, " "); /*Do not Remove this*/
            return a;
        }

        public string INQUIREQUERY(string recuser)
        {
            return $"EXEC [RE].[nsp_TRANSFERACTIVITY] @Recuser='{recuser}', @QueryType = 26";
        }

        public string MultiProcessUpdate(DataTable dt, String RecUser)
        {
            try
            {
                sqlConn.ConnectionString = _ConnectionString;
                sqlConn.Open();
                sqlTrn = sqlConn.BeginTransaction();

                SqlCommand cmd = new SqlCommand();

                foreach (DataRow dr in dt.Rows)
                {
                    cmd = new SqlCommand();
                    cmd.Connection = sqlConn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Transaction = sqlTrn;
                    cmd.Parameters.Clear();
                    cmd.CommandText = storedProcedure;
                    cmd.Parameters.AddWithValue("@DOCNO", dr["DOCNO"]);
                    cmd.Parameters.AddWithValue("@STATUS", dr["STATUS"]);
                    cmd.Parameters.AddWithValue("@QUERYTYPE", 29);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException sqlEx)
            {
                sqlTrn.Rollback();
                sqlConn.Close();
                string result;
                if (sqlEx.Number == 2627)
                    result = String.Format("Error [{0}]: \nSystem Cannot Save Data.\nDuplicate records are not allowed.", sqlEx.Number);
                else if (sqlEx.Number == 547)
                    result = String.Format("Error [{0}]: \nSystem Cannot perform action.\nData currently in use.", sqlEx.Number);
                else
                    result = String.Format("Error [{0}]: \n{1}", sqlEx.Number, sqlEx.Message);
                return result;
            }
            catch (Exception ex)
            {
                sqlTrn.Rollback();
                sqlConn.Close();
                return String.Format("Error: {0}\n", ex.Message);
            }

            sqlTrn.Commit();
            sqlConn.Close();
            return "Process has successfully completed.";
        }

        public DataTable getColumnNameFilter()
        {
            return SFObjects.LoadDataTable($"EXEC [RE].[nsp_ColEffiperBUReport] @QUERYTYPE=5", _ConnectionString);
        }

        public DataTable LoadSchema()
        {
            return SFObjects.LoadDataTable($"EXEC [RE].[nsp_ColEffiperBUReport] @QUERYTYPE=5", _ConnectionString);
        }

        public string getAddToList(int queryType, int rbPCCA, string dateFilterFrom, string dateFilterTo, string Location, string Payee, string PaymentRequestNo, string APVNo, string ReferenceNo, string user)
        {
            return $"EXEC {storedProcedure} @isPerCostCenter = '{rbPCCA}', @dateFrom = '{dateFilterFrom}', @dateTo = '{dateFilterTo}', @locformList = '{Location}', @vendorList = '{Payee}', @prfnoList = '{PaymentRequestNo}', @apvnoList = '{APVNo}', @refnoList = '{ReferenceNo}', @Recuser = '{user}', @QueryType = {queryType}";
        }

        public string GetUploadPath()
        {
            return SFObjects.returnText(@"SELECT Value FROM dbo.SystemConfig WHERE Code = 'Server_Path'", _ConnectionString);
        }

        public string getServerDate()
        {
            return SFObjects.returnText(@"SELECT FORMAT(dbo.GetNoahDate(),'MM/dd/yyyy')", _ConnectionString);
        }

        public string chkRptAccAssgn(string user)
        {
            return SFObjects.returnText($@"EXEC {storedProcedure} @Recuser = '{user}', @QueryType = 16", _ConnectionString);
        }

        public string chkLabelCC()
        {
            return SFObjects.returnText($"SELECT Description FROM SG.SEGMENT WHERE Costcenterflg = 1", _ConnectionString);
        }
    }
}