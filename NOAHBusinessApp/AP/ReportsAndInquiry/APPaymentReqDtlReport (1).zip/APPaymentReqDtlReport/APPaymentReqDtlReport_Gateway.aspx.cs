﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq; 
using NoahWebLib.Standards;
using Noah_Web.forms_BusinessLayer;

public partial class APPaymentReqDtlReport_Gateway : NoahWebLib.Standards.nwStandardGateway
{
    protected void Page_Load(object sender, EventArgs e)
    {
 
        #region  Variable needed dafaulted all as true
        isErrorCheckerMessageShow = true;
        isCompanyGet = true;
        #endregion

        Gateway_Start(sender, e);
        
        if (DLLAutoGateway == false) // for redirecting of BL (4 tier)
        {
            try
            {
                APPaymentReqDtlReportBL menuBL = new APPaymentReqDtlReportBL();
                based.Title = "Payment Request Report ";
                menuBL.main(ref strFinal, strmet,
                                        strParameter, strValue, strtool_Met,
                                        strtool_Poz, strtemp1, strtemp2,
                                        strtemp3, strtemp4, strtemp5, ref based, this.Connection);

            }
            catch (Exception err)
            {
                strFinal = err.Message.ToString();
            }

            

            Gateway_End(sender, e);
        }


    }
}
